# Food-Recipes
Frontend for a food recipes website.
home.html is the first page. I've used a video as the bg in this page, the link to which is https://www.pexels.com/video/coffee-making-art-by-a-bartender-2909914/
.On signup and login page click on submit button to move ahead
